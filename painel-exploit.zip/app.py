from flask import Flask, render_template, request, redirect, session, url_for
import subprocess
import os

app = Flask(__name__)
app.secret_key = 'Dfj49@f9F7fjq3!qsd9823nFFKdjA2#kdjfh2398J'

USERNAME = 'raidenkk'
PASSWORD = 'wolff81601623'

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = request.form.get('username')
        pwd = request.form.get('password')
        if user == USERNAME and pwd == PASSWORD:
            session['logged_in'] = True
            return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    return render_template('dashboard.html')

@app.route('/start_listener')
def start_listener():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    subprocess.Popen(['msfconsole', '-r', 'msf/handler.rc'])
    return 'Listener iniciado com sucesso!'

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)